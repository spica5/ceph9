MongoDB 3.2 NoSQL Database Server container image
====================

**The MongoDB 3.2 image is deprecated.**
