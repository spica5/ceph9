MongoDB 3.0-upg NoSQL Database Server container image
====================

**The MongoDB 3.0-upg image is deprecated.**
