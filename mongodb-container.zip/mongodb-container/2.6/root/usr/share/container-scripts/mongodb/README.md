MongoDB 2.6 NoSQL Database Server container image
====================

**The MongoDB 2.6 image is deprecated.**
