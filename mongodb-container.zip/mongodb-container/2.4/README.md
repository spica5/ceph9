MongoDB container image
====================

**The MongoDB 2.4 image is deprecated.**