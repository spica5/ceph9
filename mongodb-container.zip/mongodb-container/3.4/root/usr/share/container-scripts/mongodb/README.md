MongoDB 3.4 NoSQL Database Server container image
====================

**The MongoDB 3.4 image is deprecated.**
