# Create directory for socket

mkdir ~/socket/
