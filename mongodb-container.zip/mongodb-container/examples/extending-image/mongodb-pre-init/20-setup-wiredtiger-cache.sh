# Do not set default size for WiredTiger. It is set in configuration file.
#
# (overwrites default scripts for setting cache size)
